import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from wordcloud import WordCloud

@st.cache_data
def load_data():
    df = pd.read_csv("../data/metadata.csv")
    df['publish_time'] = pd.to_datetime(df['publish_time'], errors='coerce')
    df['year'] = df['publish_time'].dt.year
    return df

df = load_data()

st.title("CORD-19 Data Explorer")
st.write("Simple exploration of COVID-19 research papers.")

years = st.slider("Select Year Range", 2015, 2023, (2019, 2021))
filtered_df = df[(df['year'] >= years[0]) & (df['year'] <= years[1])]

papers_per_year = filtered_df['year'].value_counts().sort_index()
st.subheader("Publications per Year")
fig, ax = plt.subplots()
sns.lineplot(x=papers_per_year.index, y=papers_per_year.values, ax=ax)
st.pyplot(fig)

st.subheader("Top Journals")
top_journals = filtered_df['journal'].value_counts().head(10)
fig, ax = plt.subplots()
sns.barplot(x=top_journals.values, y=top_journals.index, ax=ax)
st.pyplot(fig)

st.subheader("Word Cloud of Titles")
text = " ".join(filtered_df['title'].dropna().tolist())
wordcloud = WordCloud(width=800, height=400, background_color="white").generate(text)
fig, ax = plt.subplots()
ax.imshow(wordcloud, interpolation="bilinear")
ax.axis("off")
st.pyplot(fig)

st.subheader("Sample Data")
st.dataframe(filtered_df.head(20))
