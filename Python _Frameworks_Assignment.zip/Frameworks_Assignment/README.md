# Frameworks Assignment - CORD-19 Data Explorer

## Overview
This project analyzes the CORD-19 metadata dataset and builds a simple Streamlit app.

## Features
- Publications per year
- Top journals
- Word cloud of paper titles
- Interactive filters in Streamlit

## Installation
```bash
git clone <your_repo_url>
cd Frameworks_Assignment
pip install -r requirements.txt
```

## Run Streamlit App
```bash
streamlit run app/streamlit_app.py
```

## Reflection
- Learned dataset cleaning, handling missing values, and visualization.
- Gained experience with Streamlit for interactive apps.
- Challenge: dataset was very large → solution: used only metadata.csv.
